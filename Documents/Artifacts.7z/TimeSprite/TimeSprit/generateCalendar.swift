//
//  generateCalendar.swift
//  TimeSprit
//
//  Created by Yunpeng Zhang on 11/14/16.
//  Copyright © 2016 Yunpeng Zhang. All rights reserved.
//

import Foundation
import UIKit
import EventKitUI

class generateCalendar: UIViewController {
    @IBOutlet weak var generateProgress: UIProgressView!
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidLoad()
        progress()
    }
    
    func progress() {
        //generateProgress.progress = 0.00
        for i in 0 ..< 100{
            
            DispatchQueue.main.async(execute: {
                self.generateProgress.setProgress(Float(i) / 100.00, animated: true)
            })
            sleep(UInt32(0.1))
        }
    }
}
