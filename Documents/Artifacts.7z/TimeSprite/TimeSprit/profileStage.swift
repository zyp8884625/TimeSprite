//
//  profileStage.swift
//  TimeSprit
//
//  Created by Yunpeng Zhang on 9/27/16.
//  Copyright © 2016 Yunpeng Zhang. All rights reserved.
//

import Foundation
import UIKit
class profileStage: UITableViewController {
    @IBOutlet weak var relextimeEndtimePicker: UIDatePicker!
    @IBOutlet weak var relextimeStarttimePicker: UIDatePicker!
    @IBOutlet var profileStageTable: UITableView!
    @IBOutlet weak var profileSaveButton: UIButton!
    
    
    @IBAction func saveButtonAction(_ sender: AnyObject) {
        let file = "profile" //this is the file. we will write to and read from it
        
        var text = "" //just a text
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        
        text += dateFormatter.string(from: relextimeEndtimePicker.date)
        text += ","
        text += dateFormatter.string(from: relextimeEndtimePicker.date)
        
        if let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            
            let path = dir.appendingPathComponent(file)
            
            //writing
            do {
                try text.write(to: path, atomically: false, encoding: String.Encoding.utf8)
            }
            catch {/* error handling here */}
            
        }
    }
}
